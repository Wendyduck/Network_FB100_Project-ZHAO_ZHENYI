import os
import re
import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import scipy.sparse as sp
import torch
from collections import Counter


# -----------------------------
# Utils (NetworkX side)
# -----------------------------
def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def load_gml_as_simple_undirected_graph(path: str) -> nx.Graph:
    """Load .gml and convert to simple undirected graph (remove self-loops)."""
    G = nx.read_gml(path)

    if G.is_directed():
        G = G.to_undirected()

    if isinstance(G, (nx.MultiGraph, nx.MultiDiGraph)):
        G = nx.Graph(G)

    G.remove_edges_from(nx.selfloop_edges(G))
    return G


def debug_node_attributes(G: nx.Graph, school: str, topk: int = 25):
    """Affiche les attributs de noeuds disponibles et leur couverture."""
    sample_node = next(iter(G.nodes()))
    print(f"\n[DEBUG] {school} sample node keys: {list(G.nodes[sample_node].keys())}")

    key_counter = Counter()
    for _, d in G.nodes(data=True):
        key_counter.update(d.keys())

    print(f"[DEBUG] {school} top-{topk} keys by coverage:")
    n = G.number_of_nodes()
    for k, c in key_counter.most_common(topk):
        print(f"  {k}: {c}/{n}")


def largest_connected_component(G: nx.Graph) -> nx.Graph:
    """Induced subgraph of the largest connected component."""
    if G.number_of_nodes() == 0:
        raise ValueError("Empty graph.")
    lcc_nodes = max(nx.connected_components(G), key=len)
    return G.subgraph(lcc_nodes).copy()


def get_node_attribute_array(G: nx.Graph, attr: str):
    """Return (nodes, values) aligned with a fixed node order."""
    nodes = list(G.nodes())
    values = [G.nodes[v].get(attr, None) for v in nodes]
    return nodes, np.array(values, dtype=object)


def normalize_labels(values: np.ndarray):
    """
    Map raw labels (object) -> int labels {0..C-1}.
    Invalid: None, "", "NA", "nan", ...
    """
    invalid_tokens = {None, "", "NA", "NaN", "nan", "null", "None"}
    n = len(values)
    valid_mask = np.ones(n, dtype=bool)

    cleaned = []
    for i, x in enumerate(values):
        if x in invalid_tokens:
            valid_mask[i] = False
            cleaned.append(None)
        else:
            cleaned.append(x)

    classes_raw = sorted(list(set([c for c in cleaned if c is not None])))
    if len(classes_raw) == 0:
        return -np.ones(n, dtype=int), valid_mask, classes_raw

    mapping = {c: i for i, c in enumerate(classes_raw)}
    y_int = -np.ones(n, dtype=int)
    for i, c in enumerate(cleaned):
        if c is None:
            continue
        y_int[i] = mapping[c]

    return y_int, valid_mask, classes_raw


def one_hot_from_int_labels(y_int: np.ndarray, n_classes: int) -> np.ndarray:
    """One-hot encode y_int (n,) into Y (n,C). Invalid (-1) remain all zeros."""
    n = len(y_int)
    Y = np.zeros((n, n_classes), dtype=np.float32)
    mask = y_int >= 0
    Y[np.where(mask)[0], y_int[mask]] = 1.0
    return Y


# -----------------------------
# (b) Label Propagation LP-Zhu (PyTorch side)
# -----------------------------
def row_normalize_sparse(A: sp.spmatrix) -> sp.csr_matrix:
    """Row-normalize: T = D^{-1}A (random-walk transition matrix)."""
    A = A.tocsr().astype(np.float32)
    deg = np.asarray(A.sum(axis=1)).ravel().astype(np.float32)
    inv_deg = np.zeros_like(deg)
    nz = deg > 0
    inv_deg[nz] = 1.0 / deg[nz]
    D_inv = sp.diags(inv_deg, format="csr")
    return D_inv @ A


def scipy_to_torch_sparse(mat: sp.spmatrix, device: str) -> torch.Tensor:
    """Scipy sparse -> torch sparse COO."""
    mat = mat.tocoo()
    idx = torch.tensor(np.vstack([mat.row, mat.col]), dtype=torch.long, device=device)
    val = torch.tensor(mat.data, dtype=torch.float32, device=device)
    return torch.sparse_coo_tensor(idx, val, mat.shape, device=device).coalesce()


def label_propagation_zhu(
    A: sp.spmatrix,
    Y0: np.ndarray,
    labeled_mask: np.ndarray,
    max_iter: int = 200,
    tol: float = 1e-6,
    device: str = "cpu",
) -> np.ndarray:
    """
    LP-Zhu (random walk + clamping on labeled nodes).
    Node classification label propagation (not community detection LPA).
    """
    T = row_normalize_sparse(A)
    Tt = scipy_to_torch_sparse(T, device=device)

    Y0t = torch.tensor(Y0, dtype=torch.float32, device=device)
    Y = Y0t.clone()
    lab = torch.tensor(labeled_mask, dtype=torch.bool, device=device)

    prev = Y
    for _ in range(max_iter):
        Y_new = torch.sparse.mm(Tt, Y)
        # clamp labeled nodes
        Y_new[lab] = Y0t[lab]

        diff = torch.norm((Y_new - prev)[~lab], p=2).item()
        denom = torch.norm(prev[~lab], p=2).item() + 1e-12
        if diff / denom < tol:
            Y = Y_new
            break

        Y = Y_new
        prev = Y_new

    return Y.detach().cpu().numpy()


# -----------------------------
# (c)(d) Evaluation
# -----------------------------
def accuracy_score(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """Accuracy as in eq.(1)."""
    return float((y_true == y_pred).mean())


def mae_01(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """0/1 MAE for categorical labels = error rate."""
    return float((y_true != y_pred).mean())


def run_attribute_experiment(
    A: sp.spmatrix,
    y_int: np.ndarray,
    valid_mask: np.ndarray,
    fractions=(0.1, 0.2, 0.3),
    n_runs: int = 5,
    seed: int = 0,
    max_iter: int = 200,
    tol: float = 1e-6,
    device: str = "cpu",
) -> pd.DataFrame:
    """
    For one attribute:
      - mask frac of known labels
      - run LP
      - evaluate on masked nodes
    Returns per-run long dataframe.
    """
    rng = np.random.RandomState(seed)
    idx_valid = np.where(valid_mask & (y_int >= 0))[0]
    if len(idx_valid) == 0:
        raise ValueError("No valid labels for this attribute.")

    n_classes = int(y_int[idx_valid].max()) + 1

    rows = []
    for frac in fractions:
        for r in range(n_runs):
            n_mask = int(round(frac * len(idx_valid)))
            masked_idx = rng.choice(idx_valid, size=n_mask, replace=False)

            labeled_mask = (y_int >= 0) & valid_mask
            labeled_mask[masked_idx] = False

            y_known = y_int.copy()
            y_known[~labeled_mask] = -1
            Y0 = one_hot_from_int_labels(y_known, n_classes)

            Ydist = label_propagation_zhu(
                A=A, Y0=Y0, labeled_mask=labeled_mask,
                max_iter=max_iter, tol=tol, device=device
            )
            y_hat = np.argmax(Ydist, axis=1).astype(int)

            y_true = y_int[masked_idx]
            y_pred = y_hat[masked_idx]

            rows.append({
                "fraction_removed": float(frac),
                "run": int(r),
                "accuracy": accuracy_score(y_true, y_pred),
                "mae": mae_01(y_true, y_pred),
                "n_masked": int(n_mask),
                "n_valid": int(len(idx_valid)),
            })

    return pd.DataFrame(rows)


def summarize_runs(df_runs: pd.DataFrame) -> pd.DataFrame:
    """Mean/std per fraction."""
    return df_runs.groupby("fraction_removed", as_index=False).agg(
        accuracy_mean=("accuracy", "mean"),
        accuracy_std=("accuracy", "std"),
        mae_mean=("mae", "mean"),
        mae_std=("mae", "std"),
        n_masked=("n_masked", "mean"),
        n_valid=("n_valid", "mean"),
    )


# -----------------------------
# Outputs (Table 1 style + plots)
# -----------------------------
def table1_style_pivot(df_summary_long: pd.DataFrame, school: str, metric: str) -> pd.DataFrame:
    """Table-1-like pivot for ONE school."""
    df_s = df_summary_long[df_summary_long["school"] == school].copy()
    return df_s.pivot_table(
        index="attribute",
        columns="fraction_removed",
        values=f"{metric}_mean",
        aggfunc="mean",
    ).sort_index()


def save_latex_table(df: pd.DataFrame, out_tex: str, caption: str, label: str):
    tex = df.to_latex(
        float_format=lambda x: f"{x:.3f}",
        caption=caption,
        label=label,
        bold_rows=False
    )
    with open(out_tex, "w", encoding="utf-8") as f:
        f.write(tex)


def plot_cross_school_accuracy(df_summary_long: pd.DataFrame, out_pdf: str, schools_order: list):
    """
    Cross-school plot:
      x = fraction_removed
      y = accuracy_mean
      colors = attributes, linestyles = schools
    """
    attributes = ["dorm", "major", "gender"]
    linestyles = ["-", "--", "-.", ":", (0, (3, 1, 1, 1)), (0, (5, 2))]

    plt.figure(figsize=(7.6, 4.8))
    for attr in attributes:
        df_a = df_summary_long[df_summary_long["attribute"] == attr].copy()
        if df_a.empty:
            continue

        for i, school in enumerate(schools_order):
            df_s = df_a[df_a["school"] == school].sort_values("fraction_removed")
            if df_s.empty:
                continue
            ls = linestyles[i % len(linestyles)]
            plt.plot(
                df_s["fraction_removed"].values,
                df_s["accuracy_mean"].values,
                marker="o",
                linestyle=ls,
                label=f"{attr} — {school}"
            )

    plt.xlabel("fraction removed")
    plt.ylabel("Accuracy")
    plt.title("LP-Zhu — Cross-school comparison (Accuracy)")
    plt.grid(True, alpha=0.3)
    plt.legend(ncol=2, fontsize=9)
    plt.tight_layout()
    plt.savefig(out_pdf)
    plt.close()


# -----------------------------
# School selection (>10) + Duke mandatory
# -----------------------------
def list_gml_files(data_dir: str):
    return [f for f in os.listdir(data_dir) if f.lower().endswith(".gml")]


def pick_schools(data_dir: str, min_schools: int = 12, duke_regex: str = r"duke", seed: int = 0):
    """Pick >= min_schools .gml files and ensure one matches Duke regex."""
    rng = np.random.RandomState(seed)
    files = list_gml_files(data_dir)
    if len(files) < min_schools:
        raise ValueError(f"Not enough .gml files in {data_dir}: found {len(files)}, need >= {min_schools}")

    duke_candidates = [f for f in files if re.search(duke_regex, f, flags=re.IGNORECASE)]
    if len(duke_candidates) == 0:
        raise ValueError(f"No Duke file found in {data_dir}. Please rename it or adjust duke_regex.")
    duke_file = sorted(duke_candidates)[0]

    others = [f for f in files if f != duke_file]
    rng.shuffle(others)

    chosen = [duke_file] + others[: max(0, min_schools - 1)]

    def school_name_from_file(fn: str):
        return os.path.splitext(fn)[0]

    return [(school_name_from_file(fn), fn) for fn in chosen]


# -----------------------------
# Main (Q5 full requirements)
# -----------------------------
def main():
    # Paths
    data_dir = "data"
    out_dir = "results_q5"
    fig_dir = os.path.join(out_dir, "figures")
    ensure_dir(out_dir)
    ensure_dir(fig_dir)

    # Requirements
    min_schools = 12  # >10 required
    fractions = (0.1, 0.2, 0.3)
    n_runs = 5
    seed = 0

    # Attributes required (task name -> field name in your .gml)
    attr_field = {
        "dorm": "dorm",
        "major": "major_index",   # <-- key fix
        "gender": "gender",
    }

    # LP parameters
    max_iter = 200
    tol = 1e-6
    device = "cpu"  # put "cuda" if you have GPU

    # Choose schools automatically and ensure Duke is included
    schools = pick_schools(data_dir, min_schools=min_schools, duke_regex=r"duke", seed=seed)

    print("Schools selected (>=12, Duke included):")
    for s, fn in schools:
        print(f" - {s}: {fn}")

    summary_long_rows = []

    # Run experiments
    for school, filename in schools:
        path = os.path.join(data_dir, filename)
        print(f"\n=== Q5 — {school} ===")

        G_raw = load_gml_as_simple_undirected_graph(path)
        G = largest_connected_component(G_raw)
        print(f"LCC: n={G.number_of_nodes()} m={G.number_of_edges()}")

        # Only debug Duke (avoid huge logs)
        if re.search(r"duke", school, re.IGNORECASE):
            debug_node_attributes(G, school)

        # adjacency
        nodes = list(G.nodes())
        A = nx.to_scipy_sparse_array(G, nodelist=nodes, format="csr", dtype=np.float32)

        print(f"[INFO] {school}: adjacency built, start attribute experiments")

        for attr in ["dorm", "major", "gender"]:
            field = attr_field[attr]
            print(f"[INFO] {school}: attr={attr}, field={field}")

            _, values_raw = get_node_attribute_array(G, field)
            y_int, valid_mask, classes_raw = normalize_labels(values_raw)

            if len(classes_raw) == 0:
                print(f"[WARN] {school} attribute '{attr}' (field='{field}'): no valid labels; skipped.")
                continue

            print(f"[Attr] {school}: {attr} classes={len(classes_raw)} valid={valid_mask.sum()}/{len(values_raw)}")

            df_runs = run_attribute_experiment(
                A=A,
                y_int=y_int,
                valid_mask=valid_mask,
                fractions=fractions,
                n_runs=n_runs,
                seed=seed + 17,
                max_iter=max_iter,
                tol=tol,
                device=device,
            )
            df_sum = summarize_runs(df_runs)

            # Save per-school per-attribute
            df_runs.to_csv(os.path.join(out_dir, f"q5_runs_{school}_{attr}.csv"), index=False)
            df_sum.to_csv(os.path.join(out_dir, f"q5_summary_{school}_{attr}.csv"), index=False)

            for _, row in df_sum.iterrows():
                summary_long_rows.append({
                    "school": school,
                    "attribute": attr,
                    "fraction_removed": float(row["fraction_removed"]),
                    "accuracy_mean": float(row["accuracy_mean"]),
                    "accuracy_std": float(0.0 if np.isnan(row["accuracy_std"]) else row["accuracy_std"]),
                    "mae_mean": float(row["mae_mean"]),
                    "mae_std": float(0.0 if np.isnan(row["mae_std"]) else row["mae_std"]),
                    "n_valid": int(row["n_valid"]),
                })

    # Global long summary
    df_summary = pd.DataFrame(summary_long_rows)
    df_summary.to_csv(os.path.join(out_dir, "q5_summary_all_schools_long.csv"), index=False)

    # ---- (d) Table 1 style for Duke (mandatory reference) ----
    duke_school = None
    for s in df_summary["school"].unique():
        if re.search(r"duke", s, flags=re.IGNORECASE):
            duke_school = s
            break
    if duke_school is None:
        raise RuntimeError("Duke summary not found; check Duke file name/regex.")

    duke_acc = table1_style_pivot(df_summary, duke_school, metric="accuracy")
    duke_mae = table1_style_pivot(df_summary, duke_school, metric="mae")

    duke_acc.to_csv(os.path.join(out_dir, "q5_table1_duke_accuracy.csv"))
    duke_mae.to_csv(os.path.join(out_dir, "q5_table1_duke_mae.csv"))

    save_latex_table(
        duke_acc,
        out_tex=os.path.join(out_dir, "q5_table1_duke_accuracy.tex"),
        caption=f"Accuracy of the label propagation algorithm on {duke_school} (Table 1 style).",
        label="tab:q5_table1_duke_acc",
    )
    save_latex_table(
        duke_mae,
        out_tex=os.path.join(out_dir, "q5_table1_duke_mae.tex"),
        caption=f"MAE (0/1 error) of the label propagation algorithm on {duke_school} (Table 1 style).",
        label="tab:q5_table1_duke_mae",
    )

    # ---- (d) Global mean across schools ----
    df_global = df_summary.groupby(["attribute", "fraction_removed"], as_index=False).agg(
        accuracy_mean=("accuracy_mean", "mean"),
        mae_mean=("mae_mean", "mean"),
    )
    pivot_global_acc = df_global.pivot(index="attribute", columns="fraction_removed", values="accuracy_mean").sort_index()
    pivot_global_mae = df_global.pivot(index="attribute", columns="fraction_removed", values="mae_mean").sort_index()

    pivot_global_acc.to_csv(os.path.join(out_dir, "q5_global_accuracy.csv"))
    pivot_global_mae.to_csv(os.path.join(out_dir, "q5_global_mae.csv"))

    save_latex_table(
        pivot_global_acc,
        out_tex=os.path.join(out_dir, "q5_global_accuracy.tex"),
        caption="Mean accuracy across all selected schools (LP-Zhu).",
        label="tab:q5_global_acc",
    )
    save_latex_table(
        pivot_global_mae,
        out_tex=os.path.join(out_dir, "q5_global_mae.tex"),
        caption="Mean MAE (0/1 error) across all selected schools (LP-Zhu).",
        label="tab:q5_global_mae",
    )

    # ---- Cross-school plot for (e) ----
    plot_cross_school_accuracy(
        df_summary_long=df_summary,
        out_pdf=os.path.join(fig_dir, "q5_cross_school_accuracy.pdf"),
        schools_order=[s for s, _ in schools],
    )

    print("\nQ5 DONE.")
    print(f"- Long summary: {out_dir}/q5_summary_all_schools_long.csv")
    print(f"- Duke Table1 (LaTeX): {out_dir}/q5_table1_duke_accuracy.tex")
    print(f"- Global mean (LaTeX): {out_dir}/q5_global_accuracy.tex")
    print(f"- Cross-school plot: {fig_dir}/q5_cross_school_accuracy.pdf")
    print("\nTip (e): dorm often highest (homophily), gender stable (few classes), major harder (many classes).")


if __name__ == "__main__":
    main()

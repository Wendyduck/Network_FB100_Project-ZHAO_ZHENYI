
from __future__ import annotations

import os
import glob
import math
import random
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple, Set

import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt


# -----------------------------
# Config (edit if needed)
# -----------------------------
DATA_DIR = "data"
OUT_DIR = "results_q4"
FIG_DIR = os.path.join(OUT_DIR, "figures")

# Evaluate on >10 graphs (default 12). You can increase to more.
MAX_GRAPHS = 12

# Edge removal fractions requested by the assignment
FRACTIONS = [0.05, 0.10, 0.15, 0.20]

# k values requested by the assignment
K_LIST = [50, 100, 200, 300, 400]

# Negative sampling size (to avoid O(n^2) full scan)
NEG_MULTIPLIER = 10  # negatives = NEG_MULTIPLIER * |E_removed|

# Random seed for reproducibility
SEED = 42

# Plot settings
PLOT_F_FIXED = 0.10   # for "performance vs k" plot
PLOT_K_FIXED = 100    # for "robustness vs f" plot


# -----------------------------
# Utilities
# -----------------------------
def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def load_gml_as_simple_undirected_graph(path: str) -> nx.Graph:
    G = nx.read_gml(path)

    if G.is_directed():
        G = G.to_undirected()

    if isinstance(G, (nx.MultiGraph, nx.MultiDiGraph)):
        G = nx.Graph(G)

    # remove self-loops
    G.remove_edges_from(nx.selfloop_edges(G))
    return G


def largest_connected_component(G: nx.Graph) -> nx.Graph:
    if G.number_of_nodes() == 0:
        raise ValueError("Empty graph.")
    lcc_nodes = max(nx.connected_components(G), key=len)
    return G.subgraph(lcc_nodes).copy()


def canonical_edge(u: Any, v: Any) -> Tuple[Any, Any]:
    if str(u) <= str(v):
        return (u, v)
    return (v, u)


def edge_set_from_graph(G: nx.Graph) -> Set[Tuple[Any, Any]]:
    return {canonical_edge(u, v) for u, v in G.edges()}


def sample_non_edges(G: nx.Graph, num_samples: int, rng: random.Random) -> List[Tuple[Any, Any]]:
    """
    Sample 'num_samples' pairs (u,v) that are NOT edges in G and u != v.
    Uses rejection sampling (fine for sparse graphs).
    """
    nodes = list(G.nodes())
    n = len(nodes)
    if n < 2 or num_samples <= 0:
        return []

    existing = edge_set_from_graph(G)
    samples: Set[Tuple[Any, Any]] = set()

    max_tries = max(10_000, num_samples * 50)

    tries = 0
    while len(samples) < num_samples and tries < max_tries:
        tries += 1
        u = nodes[rng.randrange(n)]
        v = nodes[rng.randrange(n)]
        if u == v:
            continue
        e = canonical_edge(u, v)
        if e in existing:
            continue
        samples.add(e)

    return list(samples)


def remove_random_edges(G: nx.Graph, fraction: float, rng: random.Random) -> Tuple[nx.Graph, Set[Tuple[Any, Any]]]:
    """
    Remove a fraction of edges uniformly at random.
    Returns:
      - G_train (copy of G with edges removed)
      - E_removed (set of removed edges, canonical)
    """
    edges = list(G.edges())
    m = len(edges)
    num_remove = int(round(fraction * m))
    num_remove = max(1, min(num_remove, m - 1)) if m > 1 else 0

    rng.shuffle(edges)
    removed_edges = edges[:num_remove]

    G_train = G.copy()
    G_train.remove_edges_from(removed_edges)

    E_removed = {canonical_edge(u, v) for u, v in removed_edges}
    return G_train, E_removed


# -----------------------------
# Link Prediction Base Class (as required)
# -----------------------------
class LinkPrediction(ABC):
    def __init__(self, graph: nx.Graph):
        self.graph = graph
        self.N = len(graph)

    def neighbors(self, v: Any) -> List[Any]:
        return list(self.graph.neighbors(v))

    @abstractmethod
    def fit(self) -> None:
        raise NotImplementedError("Fit must be implemented")

    @abstractmethod
    def score(self, u: Any, v: Any) -> float:
        raise NotImplementedError("score(u,v) must be implemented")


# -----------------------------
# Metrics (Q4-b) — implemented by hand
# -----------------------------
class CommonNeighbors(LinkPrediction):
    def __init__(self, graph: nx.Graph):
        super(CommonNeighbors, self).__init__(graph)
        self._nbrs: Dict[Any, Set[Any]] = {}

    def fit(self) -> None:
        self._nbrs = {v: set(self.neighbors(v)) for v in self.graph.nodes()}

    def score(self, u: Any, v: Any) -> float:
        nu = self._nbrs.get(u, set())
        nv = self._nbrs.get(v, set())
        return float(len(nu & nv))


class Jaccard(LinkPrediction):
    def __init__(self, graph: nx.Graph):
        super(Jaccard, self).__init__(graph)
        self._nbrs: Dict[Any, Set[Any]] = {}

    def fit(self) -> None:
        self._nbrs = {v: set(self.neighbors(v)) for v in self.graph.nodes()}

    def score(self, u: Any, v: Any) -> float:
        nu = self._nbrs.get(u, set())
        nv = self._nbrs.get(v, set())
        inter = len(nu & nv)
        uni = len(nu | nv)
        return float(inter / uni) if uni > 0 else 0.0


class AdamicAdar(LinkPrediction):
    def __init__(self, graph: nx.Graph):
        super(AdamicAdar, self).__init__(graph)
        self._nbrs: Dict[Any, Set[Any]] = {}
        self._inv_log_deg: Dict[Any, float] = {}

    def fit(self) -> None:
        self._nbrs = {v: set(self.neighbors(v)) for v in self.graph.nodes()}
        self._inv_log_deg = {}
        for w in self.graph.nodes():
            dw = len(self._nbrs[w])
            if dw >= 2:
                self._inv_log_deg[w] = 1.0 / math.log(dw)
            else:
                self._inv_log_deg[w] = 0.0

    def score(self, u: Any, v: Any) -> float:
        nu = self._nbrs.get(u, set())
        nv = self._nbrs.get(v, set())
        common = nu & nv
        s = 0.0
        for w in common:
            s += self._inv_log_deg.get(w, 0.0)
        return float(s)


# -----------------------------
# Evaluation (Q4-c)
# -----------------------------
@dataclass
class EvalResult:
    school: str
    n_lcc: int
    m_lcc: int
    fraction: float
    metric: str
    k: int
    tp: int
    precision: float
    recall: float


def evaluate_metric(
    metric_obj: LinkPrediction,
    G_train: nx.Graph,
    E_removed: Set[Tuple[Any, Any]],
    k_list: List[int],
    neg_multiplier: int,
    rng: random.Random,
) -> List[Tuple[int, int, float, float]]:
    """
    Evaluate one metric on one train graph with a given removed-edge set.
    Candidate set = positives (E_removed) + sampled negatives.
    Returns list of (k, tp, precision, recall).
    """
    metric_obj.fit()

    positives = list(E_removed)
    n_pos = len(positives)

    n_neg = max(1, neg_multiplier * n_pos)
    negatives = sample_non_edges(G_train, n_neg, rng=rng)

    candidates = positives + negatives

    scored: List[Tuple[float, Tuple[Any, Any]]] = []
    for (u, v) in candidates:
        s = metric_obj.score(u, v)
        scored.append((s, (u, v)))

    scored.sort(key=lambda x: x[0], reverse=True)

    removed_set = set(E_removed)

    out: List[Tuple[int, int, float, float]] = []
    for k in k_list:
        k_eff = min(k, len(scored))
        topk_edges = [e for _, e in scored[:k_eff]]
        tp = sum(1 for e in topk_edges if e in removed_set)
        precision = tp / k_eff if k_eff > 0 else 0.0
        recall = tp / n_pos if n_pos > 0 else 0.0
        out.append((k, tp, precision, recall))

    return out


def run_q4_on_graph(
    school: str,
    G_lcc: nx.Graph,
    fractions: List[float],
    k_list: List[int],
    rng: random.Random,
) -> List[EvalResult]:
    n_lcc = G_lcc.number_of_nodes()
    m_lcc = G_lcc.number_of_edges()

    all_results: List[EvalResult] = []

    for f in fractions:
        G_train, E_removed = remove_random_edges(G_lcc, f, rng=rng)

        metrics = [
            ("common_neighbors", CommonNeighbors(G_train)),
            ("jaccard", Jaccard(G_train)),
            ("adamic_adar", AdamicAdar(G_train)),
        ]

        for metric_name, metric_obj in metrics:
            eval_items = evaluate_metric(
                metric_obj=metric_obj,
                G_train=G_train,
                E_removed=E_removed,
                k_list=k_list,
                neg_multiplier=NEG_MULTIPLIER,
                rng=rng,
            )
            for (k, tp, precision, recall) in eval_items:
                all_results.append(
                    EvalResult(
                        school=school,
                        n_lcc=n_lcc,
                        m_lcc=m_lcc,
                        fraction=f,
                        metric=metric_name,
                        k=k,
                        tp=tp,
                        precision=precision,
                        recall=recall,
                    )
                )

    return all_results


# -----------------------------
# Plotting (for the report)
# -----------------------------
def _pretty_metric_name(metric: str) -> str:
    return {
        "common_neighbors": "Common Neighbors",
        "jaccard": "Jaccard",
        "adamic_adar": "Adamic-Adar",
    }.get(metric, metric)


def make_plots(df: pd.DataFrame) -> None:
    """
    Create two key plot families:
      1) Performance vs k (fixed f): Precision@k and Recall@k, 3 curves.
      2) Robustness vs f (fixed k): Precision and Recall as f increases.
    Plots use MEAN across schools + (optional) light variability via std bands.
    """
    ensure_dir(FIG_DIR)

    metrics_order = ["common_neighbors", "jaccard", "adamic_adar"]

    # Prepare mean+std table across schools
    agg = (
        df.groupby(["metric", "fraction", "k"], as_index=False)
        .agg(precision_mean=("precision", "mean"),
             precision_std=("precision", "std"),
             recall_mean=("recall", "mean"),
             recall_std=("recall", "std"))
    )

    # -----------------------------
    # (1) Performance vs k (fixed f)
    # -----------------------------
    f = PLOT_F_FIXED
    agg_f = agg[np.isclose(agg["fraction"], f)]

    # Precision vs k
    plt.figure(figsize=(7, 4.5))
    for metric in metrics_order:
        sub = agg_f[agg_f["metric"] == metric].sort_values("k")
        x = sub["k"].to_numpy()
        y = sub["precision_mean"].to_numpy()
        ystd = sub["precision_std"].fillna(0.0).to_numpy()

        plt.plot(x, y, marker="o", label=_pretty_metric_name(metric))
        # std band (helps show stability across schools)
        plt.fill_between(x, y - ystd, y + ystd, alpha=0.15)

    plt.xlabel("k")
    plt.ylabel("Precision@k (mean over schools)")
    plt.title(f"Q4 — Precision@k vs k (f = {f})")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, f"q4_precision_vs_k_f{f:.2f}.pdf"))
    plt.close()

    # Recall vs k
    plt.figure(figsize=(7, 4.5))
    for metric in metrics_order:
        sub = agg_f[agg_f["metric"] == metric].sort_values("k")
        x = sub["k"].to_numpy()
        y = sub["recall_mean"].to_numpy()
        ystd = sub["recall_std"].fillna(0.0).to_numpy()

        plt.plot(x, y, marker="o", label=_pretty_metric_name(metric))
        plt.fill_between(x, y - ystd, y + ystd, alpha=0.15)

    plt.xlabel("k")
    plt.ylabel("Recall@k (mean over schools)")
    plt.title(f"Q4 — Recall@k vs k (f = {f})")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, f"q4_recall_vs_k_f{f:.2f}.pdf"))
    plt.close()

    # -----------------------------
    # (2) Robustness vs f (fixed k)
    # -----------------------------
    k_fixed = PLOT_K_FIXED
    agg_k = agg[agg["k"] == k_fixed].sort_values("fraction")

    # Precision vs f
    plt.figure(figsize=(7, 4.5))
    for metric in metrics_order:
        sub = agg_k[agg_k["metric"] == metric].sort_values("fraction")
        x = sub["fraction"].to_numpy()
        y = sub["precision_mean"].to_numpy()
        ystd = sub["precision_std"].fillna(0.0).to_numpy()

        plt.plot(x, y, marker="o", label=_pretty_metric_name(metric))
        plt.fill_between(x, y - ystd, y + ystd, alpha=0.15)

    plt.xlabel("f (fraction of removed edges)")
    plt.ylabel(f"Precision@{k_fixed} (mean over schools)")
    plt.title(f"Q4 — Robustness: Precision@{k_fixed} vs f")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, f"q4_precision_vs_f_k{k_fixed}.pdf"))
    plt.close()

    # Recall vs f
    plt.figure(figsize=(7, 4.5))
    for metric in metrics_order:
        sub = agg_k[agg_k["metric"] == metric].sort_values("fraction")
        x = sub["fraction"].to_numpy()
        y = sub["recall_mean"].to_numpy()
        ystd = sub["recall_std"].fillna(0.0).to_numpy()

        plt.plot(x, y, marker="o", label=_pretty_metric_name(metric))
        plt.fill_between(x, y - ystd, y + ystd, alpha=0.15)

    plt.xlabel("f (fraction of removed edges)")
    plt.ylabel(f"Recall@{k_fixed} (mean over schools)")
    plt.title(f"Q4 — Robustness: Recall@{k_fixed} vs f")
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(FIG_DIR, f"q4_recall_vs_f_k{k_fixed}.pdf"))
    plt.close()

    print(f" Plots saved in: {FIG_DIR}/")


# -----------------------------
# Main
# -----------------------------
def main():
    ensure_dir(OUT_DIR)
    ensure_dir(FIG_DIR)

    rng = random.Random(SEED)

    gml_files = sorted(glob.glob(os.path.join(DATA_DIR, "*.gml")))
    if not gml_files:
        raise FileNotFoundError(f"No .gml files found in '{DATA_DIR}/'")

    selected = gml_files[:MAX_GRAPHS]
    if len(selected) < 11:
        print(f"[WARN] Only {len(selected)} graphs found/selected. The assignment asks for >10.")

    all_rows: List[EvalResult] = []

    for idx, path in enumerate(selected, 1):
        school = os.path.splitext(os.path.basename(path))[0]
        print(f"\n[{idx}/{len(selected)}] Q4 on: {school}")

        G_raw = load_gml_as_simple_undirected_graph(path)
        G_lcc = largest_connected_component(G_raw)

        print(f"  LCC: n={G_lcc.number_of_nodes()}, m={G_lcc.number_of_edges()}")

        results = run_q4_on_graph(
            school=school,
            G_lcc=G_lcc,
            fractions=FRACTIONS,
            k_list=K_LIST,
            rng=rng,
        )
        all_rows.extend(results)

    # Save raw results
    df = pd.DataFrame([r.__dict__ for r in all_rows])
    out_csv = os.path.join(OUT_DIR, "q4_results.csv")
    df.to_csv(out_csv, index=False)
    print(f"\n Saved: {out_csv}")

    # Save mean summary
    summary = (
        df.groupby(["metric", "fraction", "k"], as_index=False)[["precision", "recall"]]
        .mean()
        .sort_values(["fraction", "k", "metric"])
    )
    out_summary = os.path.join(OUT_DIR, "q4_summary_mean.csv")
    summary.to_csv(out_summary, index=False)
    print(f" Saved: {out_summary}")

    # Make the key report plots
    make_plots(df)


if __name__ == "__main__":
    main()

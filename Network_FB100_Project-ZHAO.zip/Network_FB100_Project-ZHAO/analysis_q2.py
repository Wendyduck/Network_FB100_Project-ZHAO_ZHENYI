import os
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd


# -----------------------------
# Utils
# -----------------------------
def load_gml_as_simple_undirected_graph(path: str) -> nx.Graph:
    """Load .gml, convert to simple undirected graph (remove self-loops)."""
    G = nx.read_gml(path)

    # Ensure undirected
    if G.is_directed():
        G = G.to_undirected()

    # Convert to simple Graph (in case of MultiGraph)
    if isinstance(G, (nx.MultiGraph, nx.MultiDiGraph)):
        G = nx.Graph(G)

    # Remove self-loops
    G.remove_edges_from(nx.selfloop_edges(G))
    return G


def largest_connected_component(G: nx.Graph) -> nx.Graph:
    """Return the induced subgraph of the largest connected component."""
    if G.number_of_nodes() == 0:
        raise ValueError("Empty graph.")
    lcc_nodes = max(nx.connected_components(G), key=len)
    return G.subgraph(lcc_nodes).copy()


def degree_distribution_pk(G: nx.Graph):
    """Return k values and P(k) for degree distribution (excluding k=0)."""
    degrees = np.array([d for _, d in G.degree()], dtype=int)
    if degrees.size == 0:
        return np.array([]), np.array([])
    max_k = degrees.max()
    counts = np.bincount(degrees, minlength=max_k + 1).astype(float)

    # Exclude k=0 (in LCC usually none, but keep robust)
    k = np.arange(len(counts))
    mask = (k > 0) & (counts > 0)
    k = k[mask]
    pk = counts[mask] / counts.sum()
    return k, pk


def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


# -----------------------------
# Q2 Core
# -----------------------------
def run_q2_for_university(G_lcc: nx.Graph, uni_name: str, fig_dir: str):
    """
    Compute Q2 metrics and save figures:
      - degree distribution (linear optional + log-log mandatory)
      - degree vs local clustering scatter
    Return metrics dict for table.
    """
    n = G_lcc.number_of_nodes()
    m = G_lcc.number_of_edges()

    # Q2 metrics
    density = nx.density(G_lcc)
    global_clustering = nx.transitivity(G_lcc)          # global clustering / transitivity
    mean_local_clustering = nx.average_clustering(G_lcc)

    # -------- Figure 1: Degree distribution (Linear) --------
    degrees = np.array([d for _, d in G_lcc.degree()], dtype=int)

    plt.figure(figsize=(7, 4))
    plt.hist(degrees, bins=40, edgecolor="black")
    plt.title(f"Distribution des degrés (linéaire) — {uni_name} (LCC)")
    plt.xlabel("Degré k")
    plt.ylabel("Fréquence")
    plt.tight_layout()
    plt.savefig(os.path.join(fig_dir, f"q2_degree_linear_{uni_name}.pdf"))
    plt.close()

    # -------- Figure 2: Degree distribution (Log-Log) — REQUIRED --------
    k, pk = degree_distribution_pk(G_lcc)

    plt.figure(figsize=(6, 4))
    plt.scatter(k, pk, s=12)
    plt.xscale("log")
    plt.yscale("log")
    plt.title(f"Distribution des degrés P(k) (log-log) — {uni_name} (LCC)")
    plt.xlabel("Degré k (log)")
    plt.ylabel("P(k) (log)")
    plt.tight_layout()
    plt.savefig(os.path.join(fig_dir, f"q2_degree_loglog_{uni_name}.pdf"))
    plt.close()

    # -------- Figure 3: Degree vs Local Clustering — REQUIRED --------
    local_c = nx.clustering(G_lcc)  # dict node -> c(v)
    deg_list = np.array([G_lcc.degree(v) for v in G_lcc.nodes()], dtype=int)
    c_list = np.array([local_c[v] for v in G_lcc.nodes()], dtype=float)

    plt.figure(figsize=(6, 4.5))
    plt.scatter(deg_list, c_list, s=10, alpha=0.35)
    plt.title(f"Degré vs clustering local — {uni_name} (LCC)")
    plt.xlabel("Degré k")
    plt.ylabel("Clustering local c(v)")
    plt.tight_layout()
    plt.savefig(os.path.join(fig_dir, f"q2_degree_vs_clustering_{uni_name}.pdf"))
    plt.close()

    # Print concise results (useful for sanity check)
    print(f"\n--- {uni_name} (LCC) ---")
    print(f"n = {n}, m = {m}")
    print(f"Density = {density:.6f}")
    print(f"Global clustering (transitivity) = {global_clustering:.6f}")
    print(f"Mean local clustering = {mean_local_clustering:.6f}")

    return {
        "Université": uni_name,
        "n_LCC": n,
        "m_LCC": m,
        "Density": density,
        "Clustering_global": global_clustering,
        "Clustering_moyen": mean_local_clustering,
    }


def write_latex_table(df: pd.DataFrame, out_tex_path: str, caption: str, label: str):
    """
    Write a LaTeX table that can be included via \\input{...}.
    Uses booktabs formatting.
    """
    lines = []
    lines.append("\\begin{table}[h]")
    lines.append("\\centering")
    lines.append(f"\\caption{{{caption}}}")
    lines.append(f"\\label{{{label}}}")
    lines.append("\\begin{tabular}{lrrrrr}")
    lines.append("\\toprule")
    lines.append("Université & Nœuds ($n$) & Arêtes ($m$) & Densité & Clustering global & Clustering moyen \\\\")
    lines.append("\\midrule")

    for _, row in df.iterrows():
        lines.append(
            f"{row['Université']} & {int(row['n_LCC'])} & {int(row['m_LCC'])} & "
            f"{row['Density']:.6f} & {row['Clustering_global']:.6f} & {row['Clustering_moyen']:.6f} \\\\"
        )

    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")

    with open(out_tex_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def main():
    # Fixed list required by the assignment for Q2
    universities = {
        "Caltech": "Caltech36.gml",
        "MIT": "MIT8.gml",
        "JohnsHopkins": "Johns Hopkins55.gml",
    }

    data_dir = "data"
    out_dir = "results_q2"
    fig_dir = os.path.join(out_dir, "figures")
    ensure_dir(fig_dir)

    results = []

    for name, filename in universities.items():
        path = os.path.join(data_dir, filename)
        if not os.path.exists(path):
            raise FileNotFoundError(f"File not found: {path}")

        G_raw = load_gml_as_simple_undirected_graph(path)
        G_lcc = largest_connected_component(G_raw)

        metrics = run_q2_for_university(G_lcc, name, fig_dir)
        results.append(metrics)

    # Save results table
    df = pd.DataFrame(results)
    df.to_csv(os.path.join(out_dir, "q2_metrics.csv"), index=False)

    # Generate LaTeX table for the report (to include with \input{})
    write_latex_table(
        df=df,
        out_tex_path=os.path.join(out_dir, "q2_table.tex"),
        caption="Statistiques descriptives sur la LCC (Q2).",
        label="tab:q2_stats_lcc",
    )

    print("\n Q2 terminé.")
    print(f"- Figures: {fig_dir}/q2_*.pdf")
    print(f"- Table CSV: {out_dir}/q2_metrics.csv")
    print(f"- Table LaTeX: {out_dir}/q2_table.tex (use \\input{{{out_dir}/q2_table.tex}})")


if __name__ == "__main__":
    main()

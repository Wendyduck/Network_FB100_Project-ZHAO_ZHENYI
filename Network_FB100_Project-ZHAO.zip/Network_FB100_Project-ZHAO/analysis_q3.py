import os
import glob
import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

# -----------------------------
# Config
# -----------------------------
DATA_DIR = "data"
OUT_DIR = "results_q3"
FIG_DIR = os.path.join(OUT_DIR, "figures")

# Attributes required by the assignment (matching your .gml keys)
CATEGORICAL_ATTRS = {
    "student_fac": "Status (student/faculty)",
    "major_index": "Major",
    "dorm": "Dorm",
    "gender": "Gender",
}
NUMERIC_ATTRS = {
    "degree": "Degree",
}

# Missing value convention in FB100: 0 means missing
MISSING_VALUE = 0

# -----------------------------
# Utilities
# -----------------------------
def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)


def load_gml_as_simple_undirected_graph(path: str) -> nx.Graph:
    """Load .gml, convert to undirected simple graph, remove self-loops."""
    G = nx.read_gml(path)

    # Ensure undirected
    if G.is_directed():
        G = G.to_undirected()

    # Convert to simple Graph in case of MultiGraph
    if isinstance(G, (nx.MultiGraph, nx.MultiDiGraph)):
        G = nx.Graph(G)

    # Remove self-loops
    G.remove_edges_from(nx.selfloop_edges(G))
    return G


def largest_connected_component(G: nx.Graph) -> nx.Graph:
    """Return the induced subgraph of the largest connected component."""
    if G.number_of_nodes() == 0:
        raise ValueError("Empty graph.")
    lcc_nodes = max(nx.connected_components(G), key=len)
    return G.subgraph(lcc_nodes).copy()


def filter_nodes_with_known_attribute(G: nx.Graph, attr: str, missing_value=0) -> nx.Graph:
    """
    For Q3: exclude nodes whose attribute is missing (==0).
    Return the induced subgraph on remaining nodes.
    """
    kept = []
    for v, data in G.nodes(data=True):
        val = data.get(attr, missing_value)
        if val is None:
            continue
        # Some gml values might come as strings; try to handle robustly
        try:
            # if val is numeric-like in string
            if str(val).strip() == str(missing_value):
                continue
        except Exception:
            pass

        # Standard numeric case
        if val == missing_value:
            continue

        kept.append(v)

    if len(kept) < 3:
        # Too small to compute assortativity meaningfully
        return G.subgraph([]).copy()

    return G.subgraph(kept).copy()


def safe_attribute_assortativity(G: nx.Graph, attr: str) -> float:
    """
    Compute assortativity on categorical attribute, after removing missing nodes (0).
    Return np.nan if not computable.
    """
    if G.number_of_nodes() < 3 or G.number_of_edges() < 1:
        return np.nan
    try:
        return nx.attribute_assortativity_coefficient(G, attr)
    except Exception:
        return np.nan


def safe_degree_assortativity(G: nx.Graph) -> float:
    """Compute degree assortativity; return np.nan if not computable."""
    if G.number_of_nodes() < 3 or G.number_of_edges() < 1:
        return np.nan
    try:
        return nx.degree_assortativity_coefficient(G)
    except Exception:
        return np.nan


def school_name_from_filename(path: str) -> str:
    """Pretty school name from file basename without extension."""
    base = os.path.basename(path)
    name = os.path.splitext(base)[0]
    return name


# -----------------------------
# Plotting
# -----------------------------
def plot_scatter_r_vs_n(df: pd.DataFrame, col_r: str, title: str, outpath: str):
    """
    Scatter: x=network size n (log scale), y=assortativity r, with y=0 reference line.
    """
    d = df.dropna(subset=[col_r, "n_lcc"]).copy()
    x = d["n_lcc"].values
    y = d[col_r].values

    plt.figure(figsize=(6.5, 4.2))
    plt.scatter(x, y, s=25, alpha=0.75)
    plt.xscale("log")
    plt.axhline(0.0, linestyle="--", linewidth=1)
    plt.title(title)
    plt.xlabel("Taille du réseau n (LCC) [échelle log]")
    plt.ylabel("Assortativité r")
    plt.tight_layout()
    plt.savefig(outpath)
    plt.close()


def plot_hist_kde_r(df: pd.DataFrame, col_r: str, title: str, outpath: str):
    """
    Histogram + KDE (manual simple KDE via numpy if desired is heavy).
    Here we do histogram only (safe), and optionally overlay a smooth curve via
    a gaussian KDE from scipy if installed. To keep dependencies minimal, we do hist only.
    """
    d = df.dropna(subset=[col_r]).copy()
    r = d[col_r].values

    plt.figure(figsize=(6.5, 4.2))
    plt.hist(r, bins=20, density=True, edgecolor="black", alpha=0.8)
    plt.axvline(0.0, linestyle="--", linewidth=1)
    plt.title(title)
    plt.xlabel("Assortativité r")
    plt.ylabel("Densité (histogramme)")
    plt.tight_layout()
    plt.savefig(outpath)
    plt.close()


# -----------------------------
# Main Q3 pipeline
# -----------------------------
def main():
    ensure_dir(OUT_DIR)
    ensure_dir(FIG_DIR)

    gml_files = sorted(glob.glob(os.path.join(DATA_DIR, "*.gml")))
    if len(gml_files) == 0:
        raise FileNotFoundError(f"No .gml files found in {DATA_DIR}/")

    rows = []

    print(f"Found {len(gml_files)} .gml files in {DATA_DIR}/")
    for i, path in enumerate(gml_files, 1):
        school = school_name_from_filename(path)

        # Load -> simple undirected -> LCC
        G_raw = load_gml_as_simple_undirected_graph(path)
        G_lcc = largest_connected_component(G_raw)

        n_lcc = G_lcc.number_of_nodes()
        m_lcc = G_lcc.number_of_edges()

        row = {
            "school": school,
            "n_lcc": n_lcc,
            "m_lcc": m_lcc,
        }

        # Categorical assortativity (exclude missing nodes per attribute)
        for attr in CATEGORICAL_ATTRS.keys():
            G_attr = filter_nodes_with_known_attribute(G_lcc, attr, missing_value=MISSING_VALUE)
            r = safe_attribute_assortativity(G_attr, attr)
            row[f"r_{attr}"] = r

        # Numeric: degree assortativity
        row["r_degree"] = safe_degree_assortativity(G_lcc)

        rows.append(row)

        if i % 10 == 0 or i == len(gml_files):
            print(f"[{i}/{len(gml_files)}] Processed: {school} (n={n_lcc}, m={m_lcc})")

    df = pd.DataFrame(rows)
    out_csv = os.path.join(OUT_DIR, "q3_assortativity_results.csv")
    df.to_csv(out_csv, index=False)
    print(f"\n Saved results table to: {out_csv}")

    # Plot for each attribute: scatter (r vs n) + histogram (distribution)
    for attr, attr_label in CATEGORICAL_ATTRS.items():
        col = f"r_{attr}"

        scatter_path = os.path.join(FIG_DIR, f"q3_scatter_{attr}.pdf")
        hist_path = os.path.join(FIG_DIR, f"q3_hist_{attr}.pdf")

        plot_scatter_r_vs_n(
            df, col,
            title=f"Assortativité vs taille du réseau — {attr_label}",
            outpath=scatter_path
        )
        plot_hist_kde_r(
            df, col,
            title=f"Distribution de l'assortativité — {attr_label}",
            outpath=hist_path
        )

    # Degree assortativity
    scatter_path = os.path.join(FIG_DIR, "q3_scatter_degree.pdf")
    hist_path = os.path.join(FIG_DIR, "q3_hist_degree.pdf")

    plot_scatter_r_vs_n(
        df, "r_degree",
        title="Assortativité vs taille du réseau — Degree",
        outpath=scatter_path
    )
    plot_hist_kde_r(
        df, "r_degree",
        title="Distribution de l'assortativité — Degree",
        outpath=hist_path
    )

    print("\n Figures saved to:", FIG_DIR)
    print("   - For each attribute: scatter + histogram, with r=0 reference line.")
    print("\nDone.")


if __name__ == "__main__":
    main()

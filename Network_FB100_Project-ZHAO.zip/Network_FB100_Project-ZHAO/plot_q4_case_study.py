# ============================================================
# Q4(d) — Case Study Plotter (NO re-running)
#
# Purpose:
#   Compare two specific schools (e.g., Brandeis99 vs Brown11)
#   using results already produced by analysis_q4.py.
#
# Input:
#   results_q4/q4_results.csv
#
# Output:
#   results_q4/case_study/
#       q4_case_raw_<A>_vs_<B>.csv
#       q4_case_summary_<A>_vs_<B>.csv
#       figures/
#           q4_case_precision_vs_k_<A>_vs_<B>_f0.10.pdf
#           q4_case_recall_vs_k_<A>_vs_<B>_f0.10.pdf
#           q4_case_precision_vs_f_<A>_vs_<B>_k100.pdf
#           q4_case_recall_vs_f_<A>_vs_<B>_k100.pdf
#
# Usage:
#   python plot_q4_case_study_two_schools.py
# ============================================================

from __future__ import annotations

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# -----------------------------
# Config (edit if needed)
# -----------------------------
RESULTS_CSV = os.path.join("results_q4", "q4_results.csv")

SCHOOL_A = "Brandeis99"
SCHOOL_B = "Brown11"

# For curves vs k
F_FIXED = 0.10

# For curves vs f
K_FIXED = 100

OUT_DIR = os.path.join("results_q4", "case_study")
FIG_DIR = os.path.join(OUT_DIR, "figures")

METRICS_ORDER = ["common_neighbors", "jaccard", "adamic_adar"]


def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def pretty_metric(metric: str) -> str:
    return {
        "common_neighbors": "Common Neighbors",
        "jaccard": "Jaccard",
        "adamic_adar": "Adamic-Adar",
    }.get(metric, metric)


def load_and_filter(csv_path: str, school_a: str, school_b: str) -> pd.DataFrame:
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"Cannot find results csv: {csv_path}")

    df = pd.read_csv(csv_path)

    # basic validation
    needed_cols = {"school", "fraction", "metric", "k", "precision", "recall"}
    missing = needed_cols - set(df.columns)
    if missing:
        raise ValueError(f"CSV is missing required columns: {missing}")

    df_case = df[df["school"].isin([school_a, school_b])].copy()

    if df_case.empty:
        raise ValueError(
            f"No rows found for schools {school_a} / {school_b}. "
            "Check spelling exactly as in the CSV."
        )

    found = sorted(df_case["school"].unique().tolist())
    if school_a not in found or school_b not in found:
        raise ValueError(
            f"Data not found for one of the schools.\n"
            f"Requested: {school_a}, {school_b}\n"
            f"Found: {found}\n"
            "Tip: run `python -c \"import pandas as pd; "
            f"df=pd.read_csv('{csv_path}'); print(sorted(df.school.unique())[:30])\"`"
        )

    return df_case


def save_tables(df_case: pd.DataFrame, school_a: str, school_b: str) -> None:
    ensure_dir(OUT_DIR)

    raw_out = os.path.join(OUT_DIR, f"q4_case_raw_{school_a}_vs_{school_b}.csv")
    df_case.to_csv(raw_out, index=False)

    summary = (
        df_case.groupby(["school", "metric", "fraction", "k"], as_index=False)[["precision", "recall"]]
        .mean()
        .sort_values(["school", "fraction", "k", "metric"])
    )
    summary_out = os.path.join(OUT_DIR, f"q4_case_summary_{school_a}_vs_{school_b}.csv")
    summary.to_csv(summary_out, index=False)

    print(f"[OK] Saved tables:\n  - {raw_out}\n  - {summary_out}")


def plot_precision_recall_vs_k(df_case: pd.DataFrame, school_a: str, school_b: str, f_fixed: float) -> None:
    ensure_dir(FIG_DIR)

    df_f = df_case[np.isclose(df_case["fraction"], f_fixed)].copy()
    if df_f.empty:
        available_f = sorted(df_case["fraction"].unique().tolist())
        raise ValueError(f"No data for f={f_fixed}. Available fractions: {available_f}")

    # ---------- Precision vs k ----------
    plt.figure(figsize=(8, 5))
    for metric in METRICS_ORDER:
        for school in [school_a, school_b]:
            sub = df_f[(df_f["metric"] == metric) & (df_f["school"] == school)].sort_values("k")
            if sub.empty:
                continue
            plt.plot(
                sub["k"].to_numpy(),
                sub["precision"].to_numpy(),
                marker="o",
                label=f"{school} — {pretty_metric(metric)}",
            )

    plt.xlabel("k")
    plt.ylabel("Precision@k")
    plt.title(f"Q4(d) Case study — Precision@k vs k (f = {f_fixed})")
    plt.grid(True, alpha=0.3)
    plt.legend(fontsize=8)
    plt.tight_layout()

    outp = os.path.join(FIG_DIR, f"q4_case_precision_vs_k_{school_a}_vs_{school_b}_f{f_fixed:.2f}.pdf")
    plt.savefig(outp)
    plt.close()

    # ---------- Recall vs k ----------
    plt.figure(figsize=(8, 5))
    for metric in METRICS_ORDER:
        for school in [school_a, school_b]:
            sub = df_f[(df_f["metric"] == metric) & (df_f["school"] == school)].sort_values("k")
            if sub.empty:
                continue
            plt.plot(
                sub["k"].to_numpy(),
                sub["recall"].to_numpy(),
                marker="o",
                label=f"{school} — {pretty_metric(metric)}",
            )

    plt.xlabel("k")
    plt.ylabel("Recall@k")
    plt.title(f"Q4(d) Case study — Recall@k vs k (f = {f_fixed})")
    plt.grid(True, alpha=0.3)
    plt.legend(fontsize=8)
    plt.tight_layout()

    outr = os.path.join(FIG_DIR, f"q4_case_recall_vs_k_{school_a}_vs_{school_b}_f{f_fixed:.2f}.pdf")
    plt.savefig(outr)
    plt.close()

    print(f"[OK] Saved plots:\n  - {outp}\n  - {outr}")


def plot_precision_recall_vs_f(df_case: pd.DataFrame, school_a: str, school_b: str, k_fixed: int) -> None:
    ensure_dir(FIG_DIR)

    df_k = df_case[df_case["k"] == k_fixed].copy()
    if df_k.empty:
        available_k = sorted(df_case["k"].unique().tolist())
        raise ValueError(f"No data for k={k_fixed}. Available k: {available_k}")

    # ---------- Precision vs f ----------
    plt.figure(figsize=(8, 5))
    for metric in METRICS_ORDER:
        for school in [school_a, school_b]:
            sub = df_k[(df_k["metric"] == metric) & (df_k["school"] == school)].sort_values("fraction")
            if sub.empty:
                continue
            plt.plot(
                sub["fraction"].to_numpy(),
                sub["precision"].to_numpy(),
                marker="o",
                label=f"{school} — {pretty_metric(metric)}",
            )

    plt.xlabel("f (fraction of removed edges)")
    plt.ylabel(f"Precision@{k_fixed}")
    plt.title(f"Q4(d) Case study — Precision vs f (k = {k_fixed})")
    plt.grid(True, alpha=0.3)
    plt.legend(fontsize=8)
    plt.tight_layout()

    outp = os.path.join(FIG_DIR, f"q4_case_precision_vs_f_{school_a}_vs_{school_b}_k{k_fixed}.pdf")
    plt.savefig(outp)
    plt.close()

    # ---------- Recall vs f ----------
    plt.figure(figsize=(8, 5))
    for metric in METRICS_ORDER:
        for school in [school_a, school_b]:
            sub = df_k[(df_k["metric"] == metric) & (df_k["school"] == school)].sort_values("fraction")
            if sub.empty:
                continue
            plt.plot(
                sub["fraction"].to_numpy(),
                sub["recall"].to_numpy(),
                marker="o",
                label=f"{school} — {pretty_metric(metric)}",
            )

    plt.xlabel("f (fraction of removed edges)")
    plt.ylabel(f"Recall@{k_fixed}")
    plt.title(f"Q4(d) Case study — Recall vs f (k = {k_fixed})")
    plt.grid(True, alpha=0.3)
    plt.legend(fontsize=8)
    plt.tight_layout()

    outr = os.path.join(FIG_DIR, f"q4_case_recall_vs_f_{school_a}_vs_{school_b}_k{k_fixed}.pdf")
    plt.savefig(outr)
    plt.close()

    print(f"[OK] Saved plots:\n  - {outp}\n  - {outr}")


def main() -> None:
    ensure_dir(OUT_DIR)
    ensure_dir(FIG_DIR)

    df_case = load_and_filter(RESULTS_CSV, SCHOOL_A, SCHOOL_B)

    # save tables
    save_tables(df_case, SCHOOL_A, SCHOOL_B)

    # plots: vs k (fixed f) and vs f (fixed k)
    plot_precision_recall_vs_k(df_case, SCHOOL_A, SCHOOL_B, F_FIXED)
    plot_precision_recall_vs_f(df_case, SCHOOL_A, SCHOOL_B, K_FIXED)

    print(f"\n[DONE] Case study outputs are in:\n  {OUT_DIR}/\n  {FIG_DIR}/")


if __name__ == "__main__":
    main()

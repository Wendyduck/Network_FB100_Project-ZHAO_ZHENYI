import os
import re
import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from collections import Counter

# -----------------------------
# Utils: IO + Graph
# -----------------------------
def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)

def load_gml_as_simple_undirected_graph(path: str) -> nx.Graph:
    """Load .gml and convert to simple undirected graph (remove self-loops)."""
    G = nx.read_gml(path)
    if G.is_directed():
        G = G.to_undirected()
    if isinstance(G, (nx.MultiGraph, nx.MultiDiGraph)):
        G = nx.Graph(G)
    G.remove_edges_from(nx.selfloop_edges(G))
    return G

def largest_connected_component(G: nx.Graph) -> nx.Graph:
    """Induced subgraph of the largest connected component."""
    if G.number_of_nodes() == 0:
        raise ValueError("Empty graph.")
    lcc_nodes = max(nx.connected_components(G), key=len)
    return G.subgraph(lcc_nodes).copy()

def list_gml_files(data_dir: str):
    return [f for f in os.listdir(data_dir) if f.lower().endswith(".gml")]

def pick_schools(data_dir: str, n_schools: int = 3, duke_regex: str = r"duke", seed: int = 0):
    """
    Pick a few universities, ensure one matches Duke regex.
    Returns list of (school_name, filename).
    """
    rng = np.random.RandomState(seed)
    files = list_gml_files(data_dir)
    if len(files) < n_schools:
        raise ValueError(f"Not enough .gml files in {data_dir}: found {len(files)}, need >= {n_schools}")

    duke_candidates = [f for f in files if re.search(duke_regex, f, flags=re.IGNORECASE)]
    if len(duke_candidates) == 0:
        raise ValueError(f"No Duke file found in {data_dir}. Please rename it or adjust duke_regex.")
    duke_file = sorted(duke_candidates)[0]

    others = [f for f in files if f != duke_file]
    rng.shuffle(others)
    chosen = [duke_file] + others[: max(0, n_schools - 1)]

    def school_name_from_file(fn: str):
        return os.path.splitext(fn)[0]

    return [(school_name_from_file(fn), fn) for fn in chosen]

# -----------------------------
# Utils: labels + ARI
# -----------------------------
INVALID_TOKENS = {None, "", "NA", "NaN", "nan", "null", "None"}

def get_node_attribute_array(G: nx.Graph, attr: str, nodes_order: list):
    """Return values aligned to nodes_order."""
    return np.array([G.nodes[v].get(attr, None) for v in nodes_order], dtype=object)

def normalize_labels(values: np.ndarray):
    """
    Map raw labels -> int labels {0..C-1}. Invalid -> -1.
    Returns: y_int, valid_mask, classes_raw
    """
    n = len(values)
    valid_mask = np.ones(n, dtype=bool)

    cleaned = []
    for i, x in enumerate(values):
        if x in INVALID_TOKENS:
            valid_mask[i] = False
            cleaned.append(None)
        else:
            cleaned.append(x)

    classes_raw = sorted(list(set([c for c in cleaned if c is not None])))
    if len(classes_raw) == 0:
        return -np.ones(n, dtype=int), valid_mask, classes_raw

    mapping = {c: i for i, c in enumerate(classes_raw)}
    y_int = -np.ones(n, dtype=int)
    for i, c in enumerate(cleaned):
        if c is None:
            continue
        y_int[i] = mapping[c]

    return y_int, valid_mask, classes_raw

def adjusted_rand_index(labels_true: np.ndarray, labels_pred: np.ndarray) -> float:
    """
    ARI implementation with fallback to sklearn if available.
    labels_true, labels_pred are 1D arrays of ints (same length).
    """
    try:
        from sklearn.metrics import adjusted_rand_score
        return float(adjusted_rand_score(labels_true, labels_pred))
    except Exception:
        # Manual ARI implementation (pair-counting)
        # Build contingency table
        lt = labels_true
        lp = labels_pred
        n = len(lt)
        if n <= 1:
            return 0.0

        # relabel to consecutive ints
        _, lt = np.unique(lt, return_inverse=True)
        _, lp = np.unique(lp, return_inverse=True)

        # contingency
        ct = np.zeros((lt.max() + 1, lp.max() + 1), dtype=np.int64)
        for i in range(n):
            ct[lt[i], lp[i]] += 1

        def comb2(x):
            return x * (x - 1) // 2

        sum_comb_c = np.sum([comb2(v) for v in ct.sum(axis=1)])
        sum_comb_k = np.sum([comb2(v) for v in ct.sum(axis=0)])
        sum_comb = np.sum([comb2(v) for v in ct.ravel()])

        total_pairs = comb2(n)
        if total_pairs == 0:
            return 0.0

        expected = (sum_comb_c * sum_comb_k) / total_pairs
        max_index = 0.5 * (sum_comb_c + sum_comb_k)
        denom = max_index - expected
        if denom == 0:
            return 0.0
        return float((sum_comb - expected) / denom)

# -----------------------------
# Community detection algorithms
# -----------------------------
def communities_to_labels(communities, nodes_order):
    """Convert list-of-sets communities to label vector aligned to nodes_order."""
    label_map = {}
    for cid, com in enumerate(communities):
        for v in com:
            label_map[v] = cid
    # Some nodes might be missing if algo fails (rare); assign -1
    labels = np.array([label_map.get(v, -1) for v in nodes_order], dtype=int)
    return labels

def detect_louvain(G: nx.Graph, seed: int = 0):
    """
    Louvain communities.
    Prefer NetworkX built-in louvain_communities; fallback to python-louvain if installed.
    """
    # NetworkX version
    if hasattr(nx.algorithms.community, "louvain_communities"):
        comms = nx.algorithms.community.louvain_communities(G, seed=seed)
        return comms

    
    try:
        import community as community_louvain  # python-louvain
        part = community_louvain.best_partition(G, random_state=seed)
        # convert partition dict -> list of sets
        comm_dict = {}
        for node, cid in part.items():
            comm_dict.setdefault(cid, set()).add(node)
        comms = list(comm_dict.values())
        return comms
    except Exception as e:
        raise RuntimeError(
            "Louvain not available. Please update networkx or install python-louvain.\n"
            "Try: pip install python-louvain"
        ) from e

def detect_label_propagation_communities(G: nx.Graph, seed: int = 0):
    """
    Asynchronous label propagation communities (community detection version).
    """
    comms = list(nx.algorithms.community.asyn_lpa_communities(G, seed=seed))
    return comms

# -----------------------------
# Analysis: ARI vs attributes
# -----------------------------
def compute_ari_for_school(G: nx.Graph, school: str, attrs_map: dict, seed: int = 0):
    """
    For one graph:
      - detect communities by multiple algos
      - compute ARI vs several attributes
    Returns list of dict rows.
    """
    nodes = list(G.nodes())

    # Run algorithms
    algos = {
        "louvain": detect_louvain,
        "label_propagation": detect_label_propagation_communities,
    }

    rows = []
    for algo_name, algo_fn in algos.items():
        comms = algo_fn(G, seed=seed)
        com_labels = communities_to_labels(comms, nodes)

        n_com = len(comms)
        # ignore nodes labeled -1 (should not happen often)
        valid_com_mask = com_labels >= 0

        for attr_name, field_name in attrs_map.items():
            raw = get_node_attribute_array(G, field_name, nodes)
            y_int, valid_mask, classes_raw = normalize_labels(raw)

            # optional cleaning for gender: keep only common values if you want
            # Here we keep all valid classes; if you prefer only 0/1:
            # if attr_name == "gender":
            #     valid_mask = valid_mask & np.isin(y_int, [0, 1])

            use_mask = valid_com_mask & valid_mask & (y_int >= 0)
            n_used = int(use_mask.sum())
            if n_used < 2 or len(classes_raw) < 2:
                rows.append({
                    "school": school,
                    "algorithm": algo_name,
                    "attribute": attr_name,
                    "field": field_name,
                    "ari": np.nan,
                    "n_used": n_used,
                    "n_classes_attr": int(len(classes_raw)),
                    "n_communities": int(n_com),
                })
                continue

            ari = adjusted_rand_index(y_int[use_mask], com_labels[use_mask])
            rows.append({
                "school": school,
                "algorithm": algo_name,
                "attribute": attr_name,
                "field": field_name,
                "ari": float(ari),
                "n_used": n_used,
                "n_classes_attr": int(len(classes_raw)),
                "n_communities": int(n_com),
            })

    return rows

# -----------------------------
# Plots
# -----------------------------
def plot_school_bars(df_school: pd.DataFrame, out_pdf: str, school: str):
    """
    Bar plot: ARI by attribute, grouped by algorithm for one school.
    """
    # pivot: index=attribute, columns=algorithm, values=ari
    pivot = df_school.pivot_table(index="attribute", columns="algorithm", values="ari", aggfunc="mean")
    pivot = pivot.reindex(["dorm", "major", "year", "gender"])
    pivot.plot(kind="bar", figsize=(7.8, 4.6))
    plt.title(f"ARI (communautés vs attributs) — {school}")
    plt.ylabel("ARI")
    plt.xlabel("Attribut")
    plt.grid(True, axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_pdf)
    plt.close()

def plot_global_heatmap(df: pd.DataFrame, out_pdf: str):
    """
    Heatmap of mean ARI across schools for each (algorithm, attribute).
    """
    df_mean = df.groupby(["algorithm", "attribute"], as_index=False)["ari"].mean()
    pivot = df_mean.pivot(index="attribute", columns="algorithm", values="ari")
    pivot = pivot.reindex(["dorm", "major", "year", "gender"])

    plt.figure(figsize=(6.2, 3.6))
    plt.imshow(pivot.values, aspect="auto")
    plt.xticks(np.arange(pivot.shape[1]), pivot.columns, rotation=15)
    plt.yticks(np.arange(pivot.shape[0]), pivot.index)
    plt.colorbar(label="ARI (mean across schools)")
    plt.title("ARI moyen : communautés vs attributs")
    # annotate
    for i in range(pivot.shape[0]):
        for j in range(pivot.shape[1]):
            v = pivot.values[i, j]
            if np.isnan(v):
                s = "NA"
            else:
                s = f"{v:.2f}"
            plt.text(j, i, s, ha="center", va="center", fontsize=9)
    plt.tight_layout()
    plt.savefig(out_pdf)
    plt.close()

# -----------------------------
# Main
# -----------------------------
def main():
    data_dir = "data"
    out_dir = "results_q6"
    fig_dir = os.path.join(out_dir, "figures")
    ensure_dir(out_dir)
    ensure_dir(fig_dir)

    # Choose a few universities (Duke + 2 others by default)
    seed = 0
    n_schools = 3
    schools = pick_schools(data_dir, n_schools=n_schools, duke_regex=r"duke", seed=seed)

    print("Schools selected (few, Duke included):")
    for s, fn in schools:
        print(f" - {s}: {fn}")

    # Attributes to compare with communities
    
    attrs_map = {
        "dorm": "dorm",
        "major": "major_index",
        "year": "year",
        "gender": "gender",
    }

    all_rows = []
    for school, filename in schools:
        path = os.path.join(data_dir, filename)
        print(f"\n=== Q6 — {school} ===")

        G_raw = load_gml_as_simple_undirected_graph(path)
        G = largest_connected_component(G_raw)
        print(f"LCC: n={G.number_of_nodes()} m={G.number_of_edges()}")

        # Compute ARI results
        rows = compute_ari_for_school(G, school, attrs_map=attrs_map, seed=seed)
        all_rows.extend(rows)

    df = pd.DataFrame(all_rows)
    df.to_csv(os.path.join(out_dir, "q6_ari_long.csv"), index=False)

    # Pivot mean table (nice for report)
    df_mean = df.groupby(["school", "algorithm", "attribute"], as_index=False)["ari"].mean()
    pivot = df_mean.pivot_table(index=["school", "attribute"], columns="algorithm", values="ari", aggfunc="mean")
    pivot.to_csv(os.path.join(out_dir, "q6_ari_pivot_mean.csv"))

    # Plots per school
    for school in df["school"].unique():
        df_s = df[df["school"] == school].copy()
        plot_school_bars(
            df_school=df_s,
            out_pdf=os.path.join(fig_dir, f"q6_ari_bar_{school}.pdf"),
            school=school
        )

    # Global heatmap
    plot_global_heatmap(df, out_pdf=os.path.join(fig_dir, "q6_ari_heatmap_mean.pdf"))

    print("\nQ6 DONE.")
    print(f"- Long results: {out_dir}/q6_ari_long.csv")
    print(f"- Pivot mean:  {out_dir}/q6_ari_pivot_mean.csv")
    print(f"- Figures:     {fig_dir}/q6_ari_bar_<school>.pdf and q6_ari_heatmap_mean.pdf")


if __name__ == "__main__":
    main()
